// Auto-generated. Do not edit!

// (in-package custom_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let RingIndex = require('./RingIndex.js');
let sensor_msgs = _finder('sensor_msgs');

//-----------------------------------------------------------

class VelodyneCustom {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.pointcloud = null;
      this.distance = null;
      this.azimuth = null;
      this.time = null;
      this.ring = null;
      this.index = null;
      this.fire = null;
      this.frequency = null;
    }
    else {
      if (initObj.hasOwnProperty('pointcloud')) {
        this.pointcloud = initObj.pointcloud
      }
      else {
        this.pointcloud = new sensor_msgs.msg.PointCloud2();
      }
      if (initObj.hasOwnProperty('distance')) {
        this.distance = initObj.distance
      }
      else {
        this.distance = [];
      }
      if (initObj.hasOwnProperty('azimuth')) {
        this.azimuth = initObj.azimuth
      }
      else {
        this.azimuth = [];
      }
      if (initObj.hasOwnProperty('time')) {
        this.time = initObj.time
      }
      else {
        this.time = [];
      }
      if (initObj.hasOwnProperty('ring')) {
        this.ring = initObj.ring
      }
      else {
        this.ring = [];
      }
      if (initObj.hasOwnProperty('index')) {
        this.index = initObj.index
      }
      else {
        this.index = new Array(16).fill(new RingIndex());
      }
      if (initObj.hasOwnProperty('fire')) {
        this.fire = initObj.fire
      }
      else {
        this.fire = [];
      }
      if (initObj.hasOwnProperty('frequency')) {
        this.frequency = initObj.frequency
      }
      else {
        this.frequency = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type VelodyneCustom
    // Serialize message field [pointcloud]
    bufferOffset = sensor_msgs.msg.PointCloud2.serialize(obj.pointcloud, buffer, bufferOffset);
    // Serialize message field [distance]
    bufferOffset = _arraySerializer.float32(obj.distance, buffer, bufferOffset, null);
    // Serialize message field [azimuth]
    bufferOffset = _arraySerializer.float32(obj.azimuth, buffer, bufferOffset, null);
    // Serialize message field [time]
    bufferOffset = _arraySerializer.float64(obj.time, buffer, bufferOffset, null);
    // Serialize message field [ring]
    bufferOffset = _arraySerializer.uint8(obj.ring, buffer, bufferOffset, null);
    // Check that the constant length array field [index] has the right length
    if (obj.index.length !== 16) {
      throw new Error('Unable to serialize array field index - length must be 16')
    }
    // Serialize message field [index]
    obj.index.forEach((val) => {
      bufferOffset = RingIndex.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [fire]
    bufferOffset = _arraySerializer.uint16(obj.fire, buffer, bufferOffset, null);
    // Serialize message field [frequency]
    bufferOffset = _serializer.uint8(obj.frequency, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type VelodyneCustom
    let len;
    let data = new VelodyneCustom(null);
    // Deserialize message field [pointcloud]
    data.pointcloud = sensor_msgs.msg.PointCloud2.deserialize(buffer, bufferOffset);
    // Deserialize message field [distance]
    data.distance = _arrayDeserializer.float32(buffer, bufferOffset, null)
    // Deserialize message field [azimuth]
    data.azimuth = _arrayDeserializer.float32(buffer, bufferOffset, null)
    // Deserialize message field [time]
    data.time = _arrayDeserializer.float64(buffer, bufferOffset, null)
    // Deserialize message field [ring]
    data.ring = _arrayDeserializer.uint8(buffer, bufferOffset, null)
    // Deserialize message field [index]
    len = 16;
    data.index = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.index[i] = RingIndex.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [fire]
    data.fire = _arrayDeserializer.uint16(buffer, bufferOffset, null)
    // Deserialize message field [frequency]
    data.frequency = _deserializer.uint8(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += sensor_msgs.msg.PointCloud2.getMessageSize(object.pointcloud);
    length += 4 * object.distance.length;
    length += 4 * object.azimuth.length;
    length += 8 * object.time.length;
    length += object.ring.length;
    object.index.forEach((val) => {
      length += RingIndex.getMessageSize(val);
    });
    length += 2 * object.fire.length;
    return length + 21;
  }

  static datatype() {
    // Returns string type for a message object
    return 'custom_msgs/VelodyneCustom';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'f6a5c89e46ccd723fa585f19027bdca2';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    sensor_msgs/PointCloud2 pointcloud
    float32[] distance
    float32[] azimuth
    float64[] time
    uint8[] ring
    RingIndex[16] index
    uint16[] fire
    uint8 frequency
    
    ================================================================================
    MSG: sensor_msgs/PointCloud2
    # This message holds a collection of N-dimensional points, which may
    # contain additional information such as normals, intensity, etc. The
    # point data is stored as a binary blob, its layout described by the
    # contents of the "fields" array.
    
    # The point cloud data may be organized 2d (image-like) or 1d
    # (unordered). Point clouds organized as 2d images may be produced by
    # camera depth sensors such as stereo or time-of-flight.
    
    # Time of sensor data acquisition, and the coordinate frame ID (for 3d
    # points).
    Header header
    
    # 2D structure of the point cloud. If the cloud is unordered, height is
    # 1 and width is the length of the point cloud.
    uint32 height
    uint32 width
    
    # Describes the channels and their layout in the binary data blob.
    PointField[] fields
    
    bool    is_bigendian # Is this data bigendian?
    uint32  point_step   # Length of a point in bytes
    uint32  row_step     # Length of a row in bytes
    uint8[] data         # Actual point data, size is (row_step*height)
    
    bool is_dense        # True if there are no invalid points
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    string frame_id
    
    ================================================================================
    MSG: sensor_msgs/PointField
    # This message holds the description of one point entry in the
    # PointCloud2 message format.
    uint8 INT8    = 1
    uint8 UINT8   = 2
    uint8 INT16   = 3
    uint8 UINT16  = 4
    uint8 INT32   = 5
    uint8 UINT32  = 6
    uint8 FLOAT32 = 7
    uint8 FLOAT64 = 8
    
    string name      # Name of field
    uint32 offset    # Offset from start of point struct
    uint8  datatype  # Datatype enumeration, see above
    uint32 count     # How many elements in the field
    
    ================================================================================
    MSG: custom_msgs/RingIndex
    int32[] data
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new VelodyneCustom(null);
    if (msg.pointcloud !== undefined) {
      resolved.pointcloud = sensor_msgs.msg.PointCloud2.Resolve(msg.pointcloud)
    }
    else {
      resolved.pointcloud = new sensor_msgs.msg.PointCloud2()
    }

    if (msg.distance !== undefined) {
      resolved.distance = msg.distance;
    }
    else {
      resolved.distance = []
    }

    if (msg.azimuth !== undefined) {
      resolved.azimuth = msg.azimuth;
    }
    else {
      resolved.azimuth = []
    }

    if (msg.time !== undefined) {
      resolved.time = msg.time;
    }
    else {
      resolved.time = []
    }

    if (msg.ring !== undefined) {
      resolved.ring = msg.ring;
    }
    else {
      resolved.ring = []
    }

    if (msg.index !== undefined) {
      resolved.index = new Array(16)
      for (let i = 0; i < resolved.index.length; ++i) {
        if (msg.index.length > i) {
          resolved.index[i] = RingIndex.Resolve(msg.index[i]);
        }
        else {
          resolved.index[i] = new RingIndex();
        }
      }
    }
    else {
      resolved.index = new Array(16).fill(new RingIndex())
    }

    if (msg.fire !== undefined) {
      resolved.fire = msg.fire;
    }
    else {
      resolved.fire = []
    }

    if (msg.frequency !== undefined) {
      resolved.frequency = msg.frequency;
    }
    else {
      resolved.frequency = 0
    }

    return resolved;
    }
};

module.exports = VelodyneCustom;
